# FastAPI and ReactJs Login page lemoncode21


## Backend

1. Before run our project install poetry to your pc check here https://python-poetry.org/
2. Run virtual environment or venv folder just using script `.\venv\Scripts\activate` on windows
3. Generate table to your database go to backend folder run  `alembic upgrade head`
4. Run backend using script `poetry run start`

## Frontend

1. Run frontend `npm start`
